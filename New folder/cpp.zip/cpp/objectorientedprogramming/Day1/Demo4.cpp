#include<stdio.h>

int main()
{
    wchar_t ch='@';

    printf("\nch=%c",ch);
    printf("size of ch=%d",sizeof(ch));

    return 0;
}