#include<stdio.h>
void sum(int n1,int n2 );

int main()  //main is a callback and entry point function
{
    int n1=10,n2=20;
    sum(n1,n2);     //abstraction

   return 0; 
}

void sum(int n1,int n2 )
{
    //Ecapsulation
    //int ad=n1+n2;
    printf("Sum of n1 and n2=%d",n1+n2);
}
