#include<stdio.h>

struct  Time
{
    private:
        int hr,min,sec; 
                //data members
    public:
            //member function
            void accept()
            {
            printf("\n Enter the value of hr:");
            scanf("%d",&hr);
            printf("\n Enter the value of min:");
            scanf("%d",&min);
            printf("\n Enter the value of sec:");
            scanf("%d",&sec);
            }
            
            void display()
            {

                printf("Time=%d:%d:%d",hr,min,sec);
            }

};




int main()
{
    struct  Time t;
    t.accept();
    t.display();
    return 0;
}