#include<stdio.h>

int main()
{
   int num=10;
   int & num1=num;      //constant pointer
   printf("\nNum=%d",num);
   printf("\n Num value using ref varz=%d",num1);

    return 0;
}