#include<stdio.h>

int main()
{
    bool flag=false;
    printf("\n falg val =%d",flag);
    if(flag)
        flag=false;
    else
        flag=true;

    printf("\n falg val after changing =%d",flag);
    printf("\n size of flag=%d",sizeof(flag));


    return 0;
}