#include<stdio.h>
void accept(struct Time*);
void display(struct Time*);
struct  Time
{
    int hr,min,sec;         //data members
    
};

void accept(struct  Time* t)
    {
    printf("\n Enter the value of hr:");
    scanf("%d",&t->hr);
    printf("\n Enter the value of min:");
    scanf("%d",&t->min);
    printf("\n Enter the value of sec:");
    scanf("%d",&t->sec);
    }
    

void display(struct  Time* t)
{

    printf("Time=%d:%d:%d",t->hr,t->min,t->sec);
}


int main()
{
    struct  Time t;
    accept(&t);
    display(&t);
    
    return 0;
}