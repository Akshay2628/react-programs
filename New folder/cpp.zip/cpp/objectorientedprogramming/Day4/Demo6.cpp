#include<iostream>
using namespace std;
class Complex
{
        mutable int real; //mutable data mem
        int imag;
       
    public:
        Complex()
        {
            this->real=10;
            this->imag=20;
           
        }

        void display() const  //const mem fun
        {
            this->real++;  //mutating the value of non const data mem
                            //in side const mem fun
            cout<<"real :"<<this->real<<"\t imag:"<<this->imag<<endl;
        }

};

int main()
{

    Complex c1;
    c1.display();
    return 0;
}