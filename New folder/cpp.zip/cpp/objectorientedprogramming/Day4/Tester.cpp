#include<iostream>
#include"Person.h"
using namespace std;


int main()
{
    Person p;
    p.accept();
    p.display();
    
    return 0;
}