#include<iostream>
using namespace std;
class Complex
{
        int real;
        int imag;
        static int count;       //declaration of static data member
    public:
        Complex()
        {
            this->real=10;
            this->imag=20;
            count++;        //increameting static data membre
        }

        void display()      //non static member function
        {

            cout<<"real :"<<this->real<<"\t imag:"<<this->imag<<endl;
           // cout<<"Total number of object created of Complex class:"<<Complex::count<<endl;
            Complex::display1();    //calling static mem fun from non static
                                    //mem fun 
        }

        static void display1()
        {       
            //cout<<this->real;    //not allowed this pointer dose not get passed
                                    //to static member function
            cout<<"\nTotal no. of obj of Complex classs="<<Complex::count;
        }



};

int Complex::count=0;
int main()
{
    Complex c1,c2;
    Complex::display1();
    c1.display();
    c2.display();
    return 0;
}