#include<iostream>
using namespace std;
class Heart //Dependency
{
        int beatRate;
    public:
        Heart(int br):beatRate(br)
        {}

        void print()
        {
            cout<<"Beat rate:"<<this->beatRate<<endl;
        }
        void beat()
        {
            cout<<"Heart is beating...!";
        }
};

class Human //Dependent 
{
    int age;        //data mem
    string name;    //data mem
    //data mem
    Heart heart;    //Composition
    public:
        Human(string name,Heart h):name(name),heart(h)
        {}
    void display()
    {
        cout<<"Human name:"<<this->name;
        this->heart.print();

    }
    void isAlive()
    {
        this->heart.beat();
    }

};

int main()
{
    Heart heart(70);        //Dependency object
    //it is a complex obj
    Human human("Om",heart);     //Dependent  object
    human.display();
    human.isAlive();

    return 0;
}