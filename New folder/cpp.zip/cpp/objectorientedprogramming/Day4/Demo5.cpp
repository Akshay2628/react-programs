#include<iostream>
using namespace std;

class Complex
{
        int real;
        int imag;
        
    public:
        Complex()
        {
            this->real=10;
            this->imag=20;
           
        }

        void display() const        //const mem fun
        {

            cout<<"real :"<<this->real<<"\t imag:"<<this->imag<<endl;
        }
        void print()         //non const mem fun
        {

            cout<<"real :"<<this->real<<"\t imag:"<<this->imag<<endl;
        }
};
int main()
{
    
    const Complex c1;    //constant obj
    c1.display();
    //c1.print();         //not allowed 

   
    return 0;
}