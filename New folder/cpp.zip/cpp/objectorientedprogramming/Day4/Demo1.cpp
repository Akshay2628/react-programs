#include<iostream>
using namespace std;

class Complex
{
        int real;
        int imag;
        static int count;       //declaration of static data member
    public:
        Complex()
        {
            this->real=10;
            this->imag=20;
            count++;        //increameting static data membre
        }

        void display()
        {

            cout<<"real :"<<this->real<<"\t imag:"<<this->imag<<endl;
            cout<<"Total number of object created of Complex class:"<<Complex::count<<endl;
        }

};

int Complex::count=0;       //defining the static data member globly
int main()
{
    //count=0
    Complex c1;     //count=1
    Complex c2;       //count=2

    Complex c3;
    c1.display();
    c2.display();
    c3.display();
    return 0;
}