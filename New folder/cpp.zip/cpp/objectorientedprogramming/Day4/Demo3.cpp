#include<iostream>
using namespace std;
class Complex
{
        int real;
        const int imag;  //const data member
         
    public:
        //you should initialise const data meber with member initializer list
        Complex():real(10),imag(20)     //members initializer list
        {
            this->real=10;
           // this->imag=20;    //not allowed
            
        }

        void display()
        {

            cout<<"real :"<<this->real<<"\t imag:"<<this->imag<<endl;
        }

};

int main()
{
    Complex c1;
    c1.display();
    return 0;
}
