#include<iostream>
using namespace std;

#ifndef HEADER_FILE_Person_H_
#define HEADER_FILE_Person_H_

class Person
{
    //data mem
    string name;
    int age;
    public:
        Person():name("Rajiv"),age(100)
        {}
        void accept();  //declaraion of mem function
        void display();  //declaraion of mem function

};


#endif
