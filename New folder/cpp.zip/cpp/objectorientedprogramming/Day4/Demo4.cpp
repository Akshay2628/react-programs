#include<iostream>
using namespace std;

class Complex
{
        int real;
        int imag;
          
    public:
        Complex()
        {
            this->real=10;
            this->imag=20;
                
        }
        //const member func
        void display() const
        {

           // this->real++; //Not allowed
           //non const data members act like read only in side const member func
            cout<<"real :"<<this->real<<"\t imag:"<<this->imag<<endl;
            //this->display1();//not allowed
            this->display2();//const member function call is allowed
        }

        void display1() //non const member function
        {

           // this->real++; //Not allowed
           //non const data members act like read only in side const member func
            cout<<"real :"<<this->real<<"\t imag:"<<this->imag<<endl;
            this->display3();
            //you can call const membr function from non const
            //member function
        }
        void display2() const
        {
            cout<<"Inside another const member function";
            cout<<"real :"<<this->real<<"\t imag:"<<this->imag<<endl;
        }
        void display3() const
        {
            cout<<"Inside another const member function display3()";
            cout<<"real :"<<this->real<<"\t imag:"<<this->imag<<endl;
        }

};

int main()
{
    Complex c1;
    c1.display();
    c1.display1();
    return 0;
}
