#include<iostream>
#include"Person.h"
using namespace std;

//providing the definition to the mem fun of a class which is present in header file
void Person::accept()
{

    cout<<"Enter the name of a Person:"<<endl;
    cin>>this->name;
    cout<<"Enter the age of a Person:"<<endl;
    cin>>this->age;
}
//providing the definition to the mem fun of a class which is present in header file

void Person::display()
{
    cout<<"Person name:"<<this->name<<"\t Person age:"<<this->age<<endl;
}

