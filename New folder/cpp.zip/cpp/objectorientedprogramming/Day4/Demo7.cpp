#include<iostream>
using namespace std;

class Person
{
        //data memebre declaration
        string name; //string is a class which is present in namespace std
        int age;
    public:
        Person():name("Rajiv"),age(100)
        {

        }
        void accept();   //declaration of a mem fun
        // {
        //         //definition of mem fun
        //     cout<<"\n Enter the Person name:"<<endl;
        //     cin>>this->name;
        //     cout<<"Enter the Person age:"<<endl;
        //     cin>>this->age;
        // }
        void display();//declaration of a mem fun
        // {
        //     //definition of mem fun
        //     cout<<"Person name:"<<this->name<<"\t Person age:"<<this->age;

        // }

    
};

int main()
{
    Person p;
    p.accept();
    p.display();

    return 0;
}
