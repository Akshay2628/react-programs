#include<iostream>
using namespace std;


int main()
{

    //    cout<<"Hello Sunbeam!!"; // printed message
   int num;
//    printf("\nEnter the value:");
//    scanf("%d",&num);
//    printf("%d",num);

    cout<<"\n Enter the value";
    cin>>num;
    cout<<num;

}