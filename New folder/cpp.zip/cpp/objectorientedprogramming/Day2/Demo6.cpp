#include<iostream>
using namespace std;


void sum(int num1,int num2)
{
    cout<<"Sum of int num1,int num2="<<num1+num2<<endl;
}
void sum(float num1,float num2)
{
    cout<<"Sum float num1,float num2"<<num1+num2<<endl;
}

void sum(int num1,int num2,int num3)
{
    cout<<"Sum of int num1,int num2,int num3="<<num1+num2+num3;
}
void sum(int num1,float num2)
{
       cout<<"Sum of int num1,float num2="<<num1+num2<<endl;

}
void sum(float num1,int num2)
{
       cout<<"Sum of float num1,int num2="<<num1+num2<<endl;

}

int main()
{
    // sum(10,20);
    // sum(11.1f,22.2f);
    //sum(1,2,3);
    //sum(11,22.4f);
    sum(11.4f,22);
    return 0;
}