#include<stdio.h>
int n1=10;
namespace ns1
{
    int n1=20;
    struct  Time
    {
        private:
            int hr,min,sec; 
                    //data members
        public:
                //member function
                void accept()
                {
                printf("\n Enter the value of hr:");
                scanf("%d",&hr);
                printf("\n Enter the value of min:");
                scanf("%d",&min);
                printf("\n Enter the value of sec:");
                scanf("%d",&sec);
                }
                
                void display()
                {

                    printf("Time=%d:%d:%d",hr,min,sec);
                }

    };

}
namespace ns2
{
    int n1=30;
    int n2=40;
    void display(int num)
    {
        printf("\nnum=%d",num);
    
    }
    namespace ns3       //nested namespace
    {
        int n1=50;
    }
}
int main()
{
    // printf("\n%d",n1);    //global n1
    // printf("\n%d",::n1);    //global n1
   // printf("\n%d",ns1::n1);
    
    //printf("\n%d \t %d",ns2::n1,ns2::n2);
    //printf("\n%d",ns2::ns3::n1);
    //ns2::display(12);
    struct ns1::Time t1;
    t1.accept();
    t1.display();
    
    return 0;
}