#include<iostream>
using namespace std;

inline void sum(int num1,int num2)
{
    cout<<"sum="<<num1+num2;
}

int main()
{
    sum(10,20);
return 0;
}