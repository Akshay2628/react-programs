#include<iostream>
#include<iomanip>
using namespace std;


int main()
{
    //    cout<<"\vHello Sunbeam";
    //cout<<"\\Sunbeam\\";
   // cout<<"Sunbeam Pune "<<endl<<"Sunbeam Karad";
    double f=3.12345;
    // cout<<hex<<10<<endl;
    // cout<<oct<<10<<endl;
    // cout<<setbase(16)<<10<<endl;
    // cout<<setbase(8)<<10<<endl;

    cout<<setprecision(5)<<f;
    return 0;
}