#include<iostream>
using namespace std;

void sum(int num1,int num2,int num3=10,int num4=20)
{
    cout<<"Sum="<<num1+num2+num3+num4<<endl;
}
int main()
{
    //sum(10,20,30);
    sum(10,20);
    return 0;
}