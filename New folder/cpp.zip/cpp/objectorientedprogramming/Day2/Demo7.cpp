#include<iostream>
using namespace std;//To avoid the repetative usage namespace_name:: we need to take help of using directive
int main()
{
    // std::cout<<"Hello Sunbeam Pune"<<std::endl;  //To avoid the repetative usage std:: we need to take help of using directive
    // std::cout<<"Hello Sunbeam Karad"<<std::endl;
    cout<<"Hello Sunbeam Pune"<<std::endl;
    cout<<"Hello Sunbeam Karad"<<std::endl;
return 0;
}

