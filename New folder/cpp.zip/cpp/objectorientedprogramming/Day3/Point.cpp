#include<iostream>
using namespace std;

class Point
{
    private:
         int x,y;        //data members of a class

    //member function
    public:
            //constructor is a special member function
            //It dose not have return type
            Point()
            {
                x=10;
                y=20;

            }

            Point(int a,int b)
            {
                x=a;
                y=b;
            }
            void accept()
            {
                cout<<"Enter the value for x:";
                cin>>x;
                cout<<"Entet the value for y:";
                cin>>y;

            }
            //member function
            void display()
            {
                    cout<<"x="<<x<<"\t y="<<y;
            }

};

int main()
{
    Point p1;  //  instanciation process, it will get allocate in stack memory section
    int x,y;
    cout<<"Enter the valuie for x";
    cin>>x;
    cout<<"Enter the valuie for y";
    cin>>y;
    
    Point p2(x,y);
    //p1.accept();
    //p1.display();
    p2.display();
    return 0;
}