#include<iostream>
using namespace std;

//class is a blue print or template for an object 
class Point
{
    private:
         int x,y;        //private data members of a class

    //member function
    public:
            //constructor is a special member function
            //It dose not have return type
            Point()
            {
                x=10;
                y=20;

            }
            //parameterised constructor
            Point(int a,int b)
            {
                x=a;
                y=b;
            }

            int getX()          //getter function
            {
                return x;

            }
            //setter function
            void setX(int a)
            {
                x=a;
            }
            
            int getY()          //getter function
            {
                return y;

            }
            //setter function
            void setY(int b)
            {
                y=b;
            }
            
            //Facilitator
            void accept()
            {
                cout<<"Enter the value for x:";
                cin>>x;
                cout<<"Entet the value for y:";
                cin>>y;

            }
            //member function
            //Facilitator
            void display()
            {
                    cout<<"x="<<x<<"\t y="<<y;
            }

};

int main()
{
    Point p1;  //  instanciation process, it will get allocate in stack memory section
    int x,y;
    cout<<"Enter the valuie for x";
    cin>>x;
    cout<<"Enter the valuie for y";
    cin>>y;

    Point p2(x,y);
    cout<<p2.getX();
    //p1.accept();
    //p1.display();
    //p2.display();
    return 0;
}