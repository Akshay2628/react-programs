#include<iostream>
using namespace std;

class Point 
{
    private:
             int x,y;
    public:

    //gettre for x
    int getX()
    {
        return x;
    }
    //gettre for y
    int getY()
    {
        return y;
    }
    //setter function for x
    void setX(int a)
    {
        x=a;        //setting the value/mutating of x
    }
    //setter function for y
    void setY(int b)
    {
        y=b;        //setting the value/mutating of y
    }


};

int main()
{
    Point p;
    cout<<"x="<<p.getX()<<endl;
    //cout<<"y="<<p.getY()<<endl;
    p.setX(101);
    p.setY(201);
    cout<<"x after mutation="<<p.getX();
    cout<<"y after mutation="<<p.getY();
    return 0;
}