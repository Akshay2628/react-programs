#include<iostream>
using namespace std;
class Point
{
    private:
        int x,y;            //private data members
    public:
        Point():x(10),y(20)     //constructor initializer list
        {
            //x=10;       //bad practice
            // this->x=10; //good practice
            // this->y=20;
            cout<<"Parameterless constructor called"<<endl;
        }
        Point(int x,int y):x(x),y(y)
        {
            // this->x=x;
            // this->y=y;
            
            cout<<"Parameterised constructor called"<<endl;
        }
        void accept()
        {   // this is a implecit constant pointer
            cout<<this;       //this is holding an address of a calling object
            cout<<"Ente the value of x:"<<endl;
            cin>>x;
            cout<<"Enter the value of y:"<<endl;
            cin>>y;
        }
        friend void print(Point p);
        void display()
        {
            cout<<"x="<<x<<" \ty="<<y<<endl;
        }
};
    //global function
    void print(Point p)
    {
        //to access the private data members of a Point class
        cout<<"Printing x using frien functio"<<p.x<<endl;
        cout<<"Printing y using frien functio"<<p.y<<endl;
   
    }
int main()
{
    Point p;
    print(p);
    return 0;
}