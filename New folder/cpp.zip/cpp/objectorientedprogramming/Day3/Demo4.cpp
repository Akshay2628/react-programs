#include<iostream>
using namespace std;

class Point
{
        int x,y;
    public:
        Point()
        {
            //x=10;       //bad practice
            this->x=10; //good practice
            this->y=20;
            cout<<"Parameterless constructor called"<<endl;
        }
        Point(int x,int y)
        {
            this->x=x;
            this->y=y;
            
            cout<<"Parameterised constructor called"<<endl;
        }
        void accept()
        {   // this is a implecit constant pointer
            cout<<this;       //this is holding an address of a calling object
            cout<<"Ente the value of x:"<<endl;
            cin>>this->x;
            cout<<"Enter the value of y:"<<endl;
            cin>>this->y;
        }

        void display()
        {
            cout<<"x="<<this->x<<" \ty="<<this->y<<endl;
        }
};

int main()
{
    Point p(10,20);
    p.accept();     // address =0xb4e0dff848
    return 0;
}