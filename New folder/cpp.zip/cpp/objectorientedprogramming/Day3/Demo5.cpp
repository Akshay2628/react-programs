#include<iostream>
using namespace std;

class Point
{
        int x,y;
    public:
        //in constructor initializer list we initialize data members inside declaration of a constructor 
        Point():x(10),y(20)     //constructor initializer list
        {


            //x=10;       //bad practice
            // this->x=10; //good practice
            // this->y=20;
            cout<<"Parameterless constructor called"<<endl;
        }
        Point(int x,int y):x(x),y(y)
        {
            // this->x=x;
            // this->y=y;
            
            cout<<"Parameterised constructor called"<<endl;
        }
        void accept()
        {   // this is a implecit constant pointer
            cout<<this;       //this is holding an address of a calling object
            cout<<"Ente the value of x:"<<endl;
            cin>>x;
            cout<<"Enter the value of y:"<<endl;
            cin>>y;
        }

        void display()
        {
            cout<<"x="<<x<<" \ty="<<y<<endl;
        }
};

int main()
{
    Point p(111,222);
    //p.accept();     // address =0xb4e0dff848
    p.display();
    return 0;
}