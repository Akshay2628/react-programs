#include<iostream>
using namespace std;
//Empty class 
 
class Point
{};

int main()
{
    Point p;//Empty class's object size is 1 byte
    cout<<"\n Size of Class Point="<<sizeof(p);
    return 0;
}