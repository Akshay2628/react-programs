#include<iostream>
using namespace std;

class Point
{
        int x,y;
    public:
        Point()
        {
            x=10;
            y=20;
            cout<<"inside parameterless constrructor"<<endl;
        }
        //facilitator functions
        void accept()
        {

            cout<<"Enter the value of x";
            cin>>x;
            cout<<"Enter the value of y";
            cin>>y;
        }

        //facilitator functions
        void display()
        {
            cout<<"x="<<x<<"\t y="<<y<<endl;
        }

        ~Point()
        {
            
            cout<<"Inside the destructor";
        }

};

int main()
{
    Point p1;
    p1.accept();
    p1.display();
   return 0;
}