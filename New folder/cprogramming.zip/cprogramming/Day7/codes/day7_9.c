// auto variables - local variables

#include<stdio.h>

int main()
{
    auto int num1,num2; // local variable
    return 0;
}

void fun()
{
  //  printf("%d %d",num1,num2);// not accessible

}