#include<stdio.h>
extern int num; // global variablee declaration 
int main()
{
   
    printf("num = %d",num); //variable used
    return 0;
}

int num = 10; // variable definition