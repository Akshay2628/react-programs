// nested for loop
#include<stdio.h>

int main()
{
    int i,j;

    for(i=1;i<=5;i++)
    {
        for(j=1;j<=i;j++)
        {
            printf("*");
        }
        printf("\n");
    }
    return 0;
   
}

// for each iteration of the outer loop, 
//inner loop executes till the condition is met

/*
i = 1 
        j <= i -> j=1
i = 2 
        j <= i -> j=1 , j=2
i = 3
        j <= i -> j=1 , j=2 , j=3
i = 4 
        j <= i -> j=1 , j=2 , j=3 , j=4
i = 5
        j <= i -> j=1 , j=2 , j=3 , j=4 , j=5
i = 6 -> condition false

*/