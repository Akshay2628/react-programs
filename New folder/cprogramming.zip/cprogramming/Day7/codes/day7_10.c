// register variables
// request to store the variable in cpu registers for faster access
#include<stdio.h>
int main()
{
    register int num; 
    return 0;
}