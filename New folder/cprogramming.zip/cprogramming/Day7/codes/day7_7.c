// functions with return type
#include<stdio.h>
//int add (int num1,int num2); // function declaration
int add(int ,int); // valid declaration
int main()
{
    int num1,num2;
    printf("enter value for num1 & num2 !!");
    scanf("%d%d",&num1,&num2); // 40 70
    int ans = add (num1,num2); // function call -> actual arguments 
    // ans holds the value returned from the function
    printf("ans = %d",ans);   
   // int res = add(10,30); 
    printf("ans = %d",add(10,20));

    return 0;
}
// function definition
int add (int num1,int num2) // formal arguments -> 40 70
{
    int result;
    result = num1 + num2;
    return result; // returns value

}