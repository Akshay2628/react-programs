// functions without return type -> void

#include<stdio.h>
void add(int a,int b); // function declaration

int main()
{
    int num1,num2;
    add(10,20); // function call
    add(20,30);
    add(30,40);
    add(40,50);
    printf("enter value for num1 and num2 ::");
    scanf("%d%d",&num1,&num2);
    add(num1,num2);  // actual arguments 
    return 0;
}
// function defination
void add(int a,int b) // formal arguments
{
    printf("result = %d\n",a+b);
}