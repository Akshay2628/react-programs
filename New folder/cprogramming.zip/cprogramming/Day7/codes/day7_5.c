// jump statements -> goto

#include<stdio.h>

int main()
{
    int rank;

START :
    printf("Enter your rank !!");
    scanf("%d",&rank);

    if(rank >= 1 && rank <= 5)
    {
        goto END; // goes to the label END
    }
    else
    {
        goto START; // goes to the label START
    }
    END :
        printf("Congrats !!");
    
    return 0;
}