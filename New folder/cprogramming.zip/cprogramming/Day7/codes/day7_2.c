// jump statements -> break -> used in switch and loops
#include<stdio.h>

int main()
{
    int i;
    for(i=1;i<=5;i++)
    {
        printf("%4d",i);
        if(i == 3)
            break; // jumps out of the nearest loop
    }
    return 0;
}