// jump statements -> return
#include<stdio.h>

int main()
{ 
    return 0; // returns to the calling area
    printf("Hello Everyone !!");
    return 0; 
}