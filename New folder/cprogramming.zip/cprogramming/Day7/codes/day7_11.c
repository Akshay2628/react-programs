// global variables 

#include<stdio.h>
int a,b; // global variable
void fun();
int main()
{
    printf("a = %d b = %d\n",a,b); // accessible
    fun();
    return 0;
}

void fun()
{
    printf("in fun : = %d",a); // accessible
}