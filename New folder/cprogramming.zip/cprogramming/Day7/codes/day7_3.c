// jump statement -> continue -> used only in loops
#include<stdio.h>
int main()
{
    int i;
    for(i=1;i<=10;i++)
    {
        if(i%2 == 0)
            continue; // continues to the nearest loop. does not execute the below code

        printf("%4d",i); // 1  3  5
    }
    return 0;
}