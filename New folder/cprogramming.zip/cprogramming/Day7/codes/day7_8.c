// function without arguments and without returntype
#include<stdio.h>

int main()
{
    fun();
    fun();
    fun();
    return 0;
}

void fun()
{
    int a = 10;
    printf("%d  ",a);
}