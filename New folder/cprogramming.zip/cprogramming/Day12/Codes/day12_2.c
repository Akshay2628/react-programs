// passing array to functions
#include<stdio.h>
void accept_data(int arr[2][3]);
void print_data(int arr[2][3]);
int main()
{

    int arr[2][3]; // 2*3*4 = 24
    accept_data(arr);
    print_data(arr);
    printf("size of array in main() = %d\n",sizeof(arr)); // entire array = 24
    printf("size of 1 element = %d\n",sizeof(arr[0][1])); // 4 bytes -> sizeof int
    return 0;
}

void accept_data(int arr[2][3])
{
    printf("enter the values ::");
    for(int i=0;i<2;i++) // row
    {
        for(int j=0;j<3;j++) // column
        {
            printf("arr[%d][%d] =",i,j);
            scanf("%d",&arr[i][j]);
        }
    }

    printf("size of array in accept_data() = %d\n",sizeof(arr)); 
                    // size of base address -> pointer -> 4 bytes in 32 bit compiler

}

void print_data(int arr[2][3])
{
    printf("values are ::\n");

    for(int i=0;i<2;i++)
    {
        for(int j=0;j<3;j++)
        {
            printf("arr[%d][%d] = %d    ",i,j,arr[i][j]);
        }
        printf("\n");
    }
}
