#include<stdio.h>

int main()
{
     int arr[3][3] = {1,2,3,4,5,6,7,8,9};

     printf("arr[2][1] = %d\n",arr[2][1]);
     printf("arr[2][1]=%d\n",*(*(arr+2)+1)); // pointer notation
     printf("arr[1][0] = %d\n",*(*(arr+1)+0));
     printf("arr[1][0] = %d\n",*(*(arr+1)));
    printf("arr[1][0] = %d\n",arr[1][0]);
     printf("arr[1][0] = %d",*arr[1]); // arr[1][0] 
    return 0;
}

/*
arr = base address of array
arr+1 = outer address of row
*(arr+1) = inner address of row
(*(arr+1)+1) = inner address of 1st row and 1st column
*(*(arr+1)+1) = value at arr[1][1]
*/