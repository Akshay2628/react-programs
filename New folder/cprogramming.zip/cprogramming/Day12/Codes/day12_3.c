#include<stdio.h>

int main()
{
    int arr[3][3] = {1,2,3,4,5,6,7,8,9};

    printf("arr = %u\n",arr);
    printf("arr + 1 =%u\n",arr+1); // array notation-> moves to 1st row
    printf("arr + 2 =%u\n",arr+2); // moves to 2nd row
     printf("&arr + 1 =%u\n",&arr+1); // moves entire array ahead

    return 0;
}