#include<stdio.h>

int main()
{
    int arr[3][3] = {1,2,3,4,5,6,7,8,9};
    int arr1[][3] = {1,2,3,4,5,6,7};// partial initialization
  //  int arr[2][] ={1,2,3,4,5}; // not allowed
  //  int arr[][]; not allowed

    //printing the data
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<3;j++) // j =0 ,j=1
        {
            printf("%4d",arr[i][j]);
        }
        printf("\n");
    }
    return 0;
}