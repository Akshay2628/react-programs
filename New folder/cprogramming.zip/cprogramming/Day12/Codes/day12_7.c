#include<stdio.h>
//char pointer of 1-D array
int main()
{
    char *numbers[] ={"one","two","three"};
    printf("%s\n",numbers[0]); //one
    printf("%c\n",numbers[1][2]); // o
    printf("%c",*(*(numbers+1)+2)); // o -> pointer notation
    
    return 0;
}