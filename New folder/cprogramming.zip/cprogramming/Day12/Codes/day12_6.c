#include<stdio.h>
//2-D array of char
int main()
{
    char departments [][50] = {"HR","Sales","Trainer"};

    printf("%s\n",departments[0]);
    printf("%c\n",departments[2][0]); // array notation
    printf("%c\n",*(*(departments+2)+0)); // pointer notation
    printf("%c\n",*(*(departments+2))); // pointer notation
    printf("%d\n",sizeof(departments)); // 150 -> size of 50columns *3 rows
    printf("%d\n",sizeof(departments[0])); // 50 size of 1 column
    printf("%d\n",sizeof(departments[0][0]));// size of 0th row 0th column





    return 0;
}