#include<stdio.h>
// array of pointers
int main()
{
    int arr[3][3] ={1,2,3,4,5,6,7,8,9};
    int *p[3] = {(int *)arr,(int *)(arr+1),(int *)(arr+2)}; // 1-D array
    
    for(int i=0;i<3;i++)
    {
        printf("%u\n",*(p+i)); // address of each row of 2-d array using 1-D array 
    }


    for(int i=0;i<3;i++)
    {
        printf("%4d",*(*(p+i))); // values of 2-D array using 1-D array
    }
    return 0;
}