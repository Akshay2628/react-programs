// pointers
#include<stdio.h>

int main()
{
    int num = 10; // local variable
    int *ptr = &num; // pointer variable

    printf("num = %d\n",num); // 10
    printf("num with ptr = %d\n",*ptr); // *ptr = value at ptr -> value at address -> 10
    num = 20;
    printf("num = %d\n",num); // 20
    printf("num with ptr = %d\n",*ptr); // 20
    *ptr = 30; // changing the state of num using pointer
     printf("num = %d\n",num); // 30
    printf("num with ptr = %d\n",*ptr); // 30
    return 0;
}