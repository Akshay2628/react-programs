//static var 
#include<stdio.h>
void fun();
int main()
{
    fun();
    fun();
    fun();
    return 0;
}

void fun()
{
    static int num; // initialization at time of declaration is imp for stattic vars
    num = 10; // else it does not retain the values
    printf("%d ",num);
    num++;
}