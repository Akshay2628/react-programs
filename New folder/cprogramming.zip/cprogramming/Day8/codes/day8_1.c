// static variables
#include<stdio.h>
void fun();
int main()
{
    fun();
    fun();
    fun();
    return 0;
}
void fun()
{
    int num1 = 10; // local variable -> value is not retained
    printf("%d ",num1);
    num1++;
}
