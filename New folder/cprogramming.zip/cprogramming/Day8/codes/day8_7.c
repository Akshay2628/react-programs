#include<stdio.h>

int main()
{
    int num = 50;
    int *ptr = &num;

    printf("address of num = %u\n",&num); // address of num
    printf("address of num with ptr = %u\n",ptr); // address of num
    printf("address of ptr = %u",&ptr); // address of ptr
    return 0;
}