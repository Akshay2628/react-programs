// static variables
#include<stdio.h>
static int num;
void fun();
int main()
{
    fun();
    fun();
    fun();
    return 0;
}
void fun()
{
   static int num1 = 10; // static variable -> value is retained
    printf("%d ",num1); // 10  11 12
    num1++;
}

void fun2()
{

}