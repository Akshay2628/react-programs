// recursion

#include<stdio.h>
int power(int base,int index);
int main()
{
    int result,base = 2,index = 5;
    result = power(base,index);
    printf("Result = %d",result);
    return 0;

}

int power(int base,int index)
{
    if(index == 0) // 5 4 3 2 1 0
        return 1;
    return base * power(base,--index);
}