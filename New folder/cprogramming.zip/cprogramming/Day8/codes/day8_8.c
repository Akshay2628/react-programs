// size of pointer
#include<stdio.h>

int main()
{
    int num = 10; // size of int = 4
    char ch = 'A'; // size of char = 1
    double dvar = 12.34; // size of double = 8

    int *ptr = &num;
    char *c_ptr = &ch;
    double * d_ptr = &dvar;

    printf("size of int ptr = %d\n",sizeof(ptr)); //size of int pointer = 4
    printf("size of char ptr = %d\n",sizeof(c_ptr));// size of char pointer = 4
    printf("size of double ptr = %d\n",sizeof(d_ptr)); // size of double pointer = 4
    return 0;
}