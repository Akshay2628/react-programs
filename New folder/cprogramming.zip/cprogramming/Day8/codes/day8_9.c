#include<stdio.h>
// void pointer -> generic pointer
int main()
{
    int num = 10;
    char ch = 'Z';
    void *ptr = &num; // storing address of int num

    printf("value of num using ptr = %d\n",*(int *)ptr); // typecasting to int *
    ptr = &ch; // storing address of char ch
    printf("value of ch using ptr = %c",*(char *)ptr); // typecasting to char *
    return 0;
}