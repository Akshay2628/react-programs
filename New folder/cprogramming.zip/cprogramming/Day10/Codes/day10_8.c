    #include<stdio.h>
// const keyword
int main()
{  
    float PI = 3.14;

    float *ptr = &PI;

    printf("Value of PI = %f\n",PI);
    printf("Value of PI with pointer = %f\n",*ptr);

    // value changed with the pointer
    *ptr = 3.18;

    printf("Value of PI = %f\n",PI);
    printf("Value of PI with pointer = %f\n",*ptr);
   
   // value changed with the variable
    PI = 3.20;



    return 0;
}