#include<stdio.h>

int main()
{
    int arr[5] = {10,20,30,40,50};

    printf("arr[0] with array notation = %d\n",arr[0]);
    printf("arr[0] with pointer notation = %d\n",*arr);
    printf("arr[1] with pointer notation = %d\n",*(arr+1));
    printf("arr[1] with pointer notation = %d\n",*arr+1);// base element = 10+1 = 11

    // printing with pointer notation
    for(int i =0;i<5;i++) // 0 1
    {
        printf("arr[%d] = %d  address- arr[%d] = %u\n",i,*(arr+i),i,arr+i);
    }

    printf("arr[1] = %d",*(arr+1)+5);// arr[1] = 20 +5 = 25

arr[3] = 33; // changing array element 
/*
arr = 100
arr + 1= 100 + 1*4(scale factor for int) = 100 + 4 = 104
arr + 2 = 100 + 2*4 = 100 + 8 = 108
*/
    


    return 0;
}