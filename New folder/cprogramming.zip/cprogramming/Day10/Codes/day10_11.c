#include<stdio.h>
// const keyword
int main()
{
   const float PI = 3.14,PJ;

    float const * const ptr = &PI;
 
 // value constant for corresponding variable as well as address constant 
    printf("Value of PI = %f\n",PI);
    printf("Value of PI with pointer = %f\n",*ptr);

   // *ptr = 3.20; not allowed as value cannot be changed through constant pointer
   // ptr = &PJ; // not allowed

    // PI = 3.20; not allowed as variable is constant
    printf("Value of PI = %f\n",PI);
    printf("Value of PI with pointer = %f\n",*ptr);

   



    return 0;
}