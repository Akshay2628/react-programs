#include<stdio.h>

int main()
{
    int arr[5];
    int arr1[5];

    printf("Enter array elements ::");
// scanf with array notation
    for(int i = 0;i<5;i++)
    {
        printf("arr[%d] = ",i);
        scanf("%d",&arr[i]); // arr[0] arr[1] arr[2] arr[3] arr[4]
    }
 // scanf with pointer notation
    for(int i = 0;i<5;i++)
    {
        printf("arr[%d] = ",i);
        scanf("%d",arr+i);

    }
    return 0;
}
/*
arr + i
arr = base address -> pointer -> 100
arr+i = arr + 0 -> 100 + 0 -> 100 arr[0]
arr+i = arr+ 1 -> 100 + 1*4 -> 100 +4 -> 104 -> arr[1]
arr+i = arr + 2 -> 100 + 2*4 -> 100 + 8 = 108 -> arr[2]
*/