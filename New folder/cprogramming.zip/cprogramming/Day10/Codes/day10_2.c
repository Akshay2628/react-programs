#include<stdio.h>

int main()
{
    int arr[5] = {10,20,30,40,50};

    printf("size of an array = %d\n",sizeof(arr)); // size of entire array->
                                                    // no of elements * size of datatype
    printf("size of an array element = %d\n",sizeof(arr[0])); //size of single element

    printf("arr[0] = %d\n",arr[0]);
    printf("arr[1] = %d",1[arr]); // allowed

    return 0;
}