// arrays 
#include<stdio.h>

int main()
{
    int arr[5]; // remaining initialized to garbage
    arr[0] = 11;
    arr[1] = 22;
    arr[2] = 33;

    int arr1[5] = {10,20,30,40}; // remaining initialized to 0

    int arr2[] = {1,2,3,4,5,6,7}; // allowed -> size of array will be according to number of elements

   // int arr3[]; -> not allowed


    return 0;
}