#include<stdio.h>

int main()
{
    int arr[5] = {11,22,33,44,55};

    // printing with array notation
    for(int i=0;i<5;i++)
    {
        printf("arr[%d] = %d  address- arr[%d] = %u\n",i,arr[i],i,&arr[i]);
    }
    return 0;
}