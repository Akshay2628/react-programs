#include<stdio.h>

int main()
{
    int arr[5] = {1,  2,  3,  4,  5};
    //           100 104  108 112 116 120

    for(int i = 0;i<5;i++)
    {

        printf("arr[%d] = %d  address - arr[%d] = %u\n",i,*(arr+i),i,arr+i);
    }

    printf("address = %u\n",&arr+1); // entire block + 1
    // &arr + 1 -> base address + 20 bytes (5 elements * 4 bytes each)
    printf("address = %u",&arr+2); // entire block + 2
    // &arr + 2 * 20 bytes = 40 bytes

    return 0;
}