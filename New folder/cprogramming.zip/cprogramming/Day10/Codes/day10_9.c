#include<stdio.h>
// const keyword
int main()
{
   const float PI = 3.14;

    float *ptr = &PI;

    printf("Value of PI = %f\n",PI);
    printf("Value of PI with pointer = %f\n",*ptr);

    // value changed with the pointer
    *ptr = 3.18;
   // PI = 3.12; not allowed to change value as variable is constant


    printf("Value of PI = %f\n",PI);
    printf("Value of PI with pointer = %f\n",*ptr);

   



    return 0;
}