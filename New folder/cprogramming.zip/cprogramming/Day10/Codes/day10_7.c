// passing arrays to functions
#include<stdio.h>
void accept_data(int arr[5]);
void print_data(int arr[5]);
int main()
{
    int arr[5];
    accept_data(arr); // name of array is the base address
    print_data(arr);
    printf("size of array = %d",sizeof(arr)); // size of entire array

    return 0;
}

void accept_data(int arr[5]) // only base address passed to function
{
    printf("Enter the values ::");

    for(int i =0 ; i<5 ;i++)
    {
        printf("arr[%d] =",i);
        scanf("%d",&arr[i]); // pointer notation -> arr+i
    }
    printf("size of array in function = %d",sizeof(arr)); // size of base address
}

void print_data(int arr[5])
{
    printf("Array elements are ::\n");
    for(int i = 0;i<5;i++)
    {
        printf("arr[%d] = %d\n",i,arr[i]); // pointer notation *(arr+i)
    }
}