#include<stdio.h>
// const keyword
int main()
{
   const float PI = 3.14,PJ;

    float const * ptr = &PI; //  value constant for corresponding variable
 // const float *ptr = &PI // same functionality as above-> allowed syntax
    printf("Value of PI = %f\n",PI);
    printf("Value of PI with pointer = %f\n",*ptr);

   // *ptr = 3.20; not allowed as value cannot be changed through constant pointer
    ptr = &PJ; // address with the pointer can be changed

    // PI = 3.20; not allowed as variable is constant
    printf("Value of PI = %f\n",PI);
    printf("Value of PI with pointer = %f\n",*ptr);

   



    return 0;
}