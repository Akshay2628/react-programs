// passing structure to a function and returing structure from a function
#include<stdio.h>

struct date
{
    int dd;
    int mm;
    int yy;
};

struct date accept_date();
void print_date(struct date dt);

int main()
{
    struct date d1;
    d1 = accept_date();
    print_date(d1);
    return 0;
}

struct date accept_date() 
{
    struct date dt;
    printf("enter the date in dd mm and yy ::");
    scanf("%d%d%d",&dt.dd,&dt.mm,&dt.yy);

    return dt;

}

void print_date(struct date dt)
{
    printf("the date is ::");
    printf("%d - %d - %d",dt.dd,dt.mm,dt.yy);
}