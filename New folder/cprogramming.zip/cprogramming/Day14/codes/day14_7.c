#include<stdio.h>
#pragma pack(1)
struct student
{
    int roll_no; //4 ->
    char name[20]; //20 -> 
    char grade; // 1 
    // 25 bytes ->
};

int main()
{
    struct student s1;

    printf("%d ",sizeof(s1));

    return 0;
}