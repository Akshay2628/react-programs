#include<stdio.h>
int main()
{
    char *p1="dipak";
    char *p2;
    p2=p1;
    p1="patil";
    printf("%s\n",p2);
    printf("%s\n",p1);

    printf("good morning"-8);
    return 0;
}