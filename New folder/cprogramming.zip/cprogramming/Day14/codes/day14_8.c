// nested structures
#include<stdio.h>

struct date
{
    int dd;
    int mm;
    int yy;
};

struct student 
{
    int roll_no;
    struct
    {
        char F_name[10];
        char M_name[10];
        char L_name[10];
    }nm;
    struct date DOB;
    float marks;
};

int main()
{
    struct student s1;
    printf("enter the details ::");
    printf("Enter the roll no ::");
    scanf("%d",&s1.roll_no);

    printf("Enter the first name ,Middle name and last name ::");
    scanf("%s%s%s",&s1.nm.F_name,&s1.nm.M_name,&s1.nm.L_name);

    printf("enter the date of birth ::");
    scanf("%d%d%d",&s1.DOB.dd,&s1.DOB.mm,&s1.DOB.yy);

    printf("enter the marks ::");
    scanf("%f",&s1.marks);

    printf("the student details are ::\n");
    printf("%d  %s.%s.%s\n",s1.roll_no,s1.nm.F_name,s1.nm.M_name,s1.nm.L_name);

    printf("%d-%d-%d   %.2f",s1.DOB.dd,s1.DOB.mm,s1.DOB.yy,s1.marks);


    return 0;
}