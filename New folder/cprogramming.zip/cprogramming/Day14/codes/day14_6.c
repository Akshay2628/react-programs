// using 1 structure into another structure
#include<stdio.h>

struct date
{
    int dd;
    int mm;
    int yy;
};

struct employee
{
    int emp_id;
    char name[20];
    float salary;
    struct date DOJ;
};

void print_data (struct employee emp);

int main()
{
    struct employee emp;
    printf("Enter the details ::");

    printf("Enter the Employee Id ::");
    scanf("%d",&emp.emp_id);

    printf("enter the name ::");
    scanf("%s",&emp.name);

    printf("enter the salary ::");
    scanf("%f",&emp.salary);

    printf("Enter the date of joining ::");
    scanf("%d%d%d",&emp.DOJ.dd,&emp.DOJ.mm,&emp.DOJ.yy);

    print_data(emp);

    return 0;
}

void print_data (struct employee emp)
{
    printf("The employee details are ::\n");
    printf("%d   %s   %.f\n",emp.emp_id,emp.name,emp.salary);
    printf("date of joining = %d-%d-%d",emp.DOJ.dd,emp.DOJ.mm,emp.DOJ.yy);

}