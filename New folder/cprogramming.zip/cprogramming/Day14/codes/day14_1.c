// using pointers with structures :
// . operator is used with structure variable
// -> operator is used with pointer variable
#include<stdio.h>

struct  employee
{
    int emp_id;
    char name[20];
    float salary;
};

int main()
{
    struct employee emp;

    struct employee *ptr = &emp;

    printf("enter the details ::");
    printf("Emp id=");
   // scanf("%d",&emp.emp_id); // scanning using noraml variable
    scanf("%d",&ptr->emp_id); // scanning using pointer variable

    printf("Enter the name ::");
    scanf("%s",ptr->name);

    printf("enter the salary ::");
    scanf("%f",&ptr->salary);

    printf("The details are ::\n");
    printf("%d    %s    %.2f",ptr->emp_id,ptr->name,ptr->salary);
    // printing with pointer variable
    
    printf("%d    %s    %.2f",emp.emp_id,emp.name,emp.salary);
    //printing with structure variable 
}
