// copying 1 structure variable into another
#include<stdio.h>

struct student
{
    int roll_no;
    char name [20];
    float marks;
};

int main()
{
    struct student s1 = {1,"Nisha",100};
    printf(" s1 = %d  %s   %.2f\n",s1.roll_no,s1.name,s1.marks);

    struct student s2;
    
    s2 = s1; // copying 1 variable to another

     printf(" s2 = %d  %s   %.2f",s2.roll_no,s2.name,s2.marks);

     if(s1.marks == s2.marks)
     {
         printf("\nEqual ");
     }
     else
     {
         printf("\nNot Equal !!");
     }
     
    return 0;
}