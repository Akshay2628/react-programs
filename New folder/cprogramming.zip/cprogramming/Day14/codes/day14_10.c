// unions

#include<stdio.h>

union test
{
    int a; 
    char b; 
};

int main()
{
    union test ut;
    ut.a = 60;

    printf("a= %d\n",ut.a); // a = 60

    ut.b = 'a';
    printf("a= %d",ut.a); //a = 97 -> value overwritten

}
