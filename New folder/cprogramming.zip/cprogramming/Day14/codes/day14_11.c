#include<stdio.h>
struct student 
{
    int roll_no;
    char name[20];
    int std;
    union 
    {
        int marks;
        char grade;
    }result;
    
};

int main()
{
    struct student s1;

    printf("enter the details ::");

    printf("enter the roll_no ::");
    scanf("%d",&s1.roll_no);

    printf("enter the name ::");
    scanf("%s",s1.name);

    printf("Enter the standard ::");
    scanf("%d",&s1.std);

    if(s1.std <= 4)
    {
    printf("enter the grade ::");
        scanf("%*c%c",&s1.result.grade);
    }

    else
    {
        printf("enter the marks ::");
        scanf("%d",&s1.result.marks);
    }

    printf("The student details are ::");

    printf("%d  %s  %d",s1.roll_no,s1.name,s1.std);

    if(s1.std <= 4)
        printf("  %c",s1.result.grade);
    else
    {
        printf("  %d",s1.result.marks);
    }
    
    
    return 0;
}