// bitfields 
#include<stdio.h>


struct employee
{
    int emp_id; // 4 bytes
   unsigned int age : 7;
   unsigned int gender :1; // 0 0r 1 -> 0 -> male 1-> female
};

int main()
{
    struct employee emp;
    int age,gender;
    printf("size = %d \n",sizeof(struct employee));

    printf("enter the emp_id ::");
    scanf("%d",&emp.emp_id);

    printf("enter the age ::");
    scanf("%d",&age);
    // & address of operator does not work with bitfields -> so we scan the data into normal variable
    emp.age = age;
    // and assign the variable data to structure element

    printf("enter the gender in 0: male 1: Female ::");
    scanf("%d",&gender);

    emp.gender = gender;

    printf("%d  %d  %d",emp.emp_id,emp.age,emp.gender);




    return 0;
}