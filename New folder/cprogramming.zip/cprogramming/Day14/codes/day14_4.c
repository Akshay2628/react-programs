#include<stdio.h>
struct student
{
    int roll_no;
    char name[20];
    float marks;
};
void accept_data(struct student *ptr);
void print_data (struct student s1);

int main()
{
    struct student s1;
    accept_data(&s1); // address of variable
    print_data(s1);
}

void accept_data(struct student *ptr) // pass by reference / pass by address
{
    printf("Enter the details ::\n");
    printf("enter the name ::");
    scanf("%s",&ptr->name);

    printf("enter the roll_no ::");
    scanf("%d",&ptr->roll_no);

    printf("enter the marks ::");
    scanf("%f",&ptr->marks);
}

void print_data (struct student s1) // pass by value
{
    printf("The details are ::");
    printf("%d   %s   %.f",s1.roll_no,s1.name,s1.marks);
}