#include<stdio.h>

int main()
{

    FILE *fptr;
    char ch;
    fptr= fopen("sunbeam.txt","r");

    printf("file position=%ld\n",ftell(fptr));
     
}