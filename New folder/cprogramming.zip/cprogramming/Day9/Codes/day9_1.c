#include<stdio.h>

int main()
{
    int num =10;
    int *ptr = &num; // initialized -> referencing
    int *d_ptr ; // wild pointer
    int *f_ptr = NULL ; // null pointer
    void *v_ptr; // void pointer

    printf("num = %d\n",num);
    printf("num with ptr = %d",*ptr); // dereferencing

    return 0;
}