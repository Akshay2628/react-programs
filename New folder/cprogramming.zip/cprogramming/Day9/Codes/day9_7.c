// address of integer in char pointer 
#include<stdio.h>

int main()
{
    int num = 257;
    char *ptr = &num; 

    printf("num = %d\n",num);
    printf("num with ptr = %d",*ptr); // dereferences till 1 byte as it is char pointer
    return 0;
}