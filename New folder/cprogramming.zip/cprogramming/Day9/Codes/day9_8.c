// arrays declaration and printing

#include<stdio.h>

int main()
{
    // type 1
    int arr[5]; // array declaration -> default initialized to garbage
    arr[0] = 11;
    arr[1] = 22;// partial values assigned -> remaining initialized to garbage
    // type 2
    int arr1[5] = {11,22,33,44,55};// initialization
    // type 3
    int arr2[5] = {10,20,30};// partial initialization -> remaining values initialized to 0

    printf("arr2[3] = %d\n",arr2[3]); // prints 0
    printf("arr[2] = %d\n",arr[2]); // prints garbage

    // printing array values with loop
    for(int i = 0;i<5;i++)
    {
        printf("%4d",arr1[i]);
    }
    return 0;
}