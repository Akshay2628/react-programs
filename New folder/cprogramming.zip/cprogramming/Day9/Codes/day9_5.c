//pointer arithmetic
#include<stdio.h>

int main()
{
    int num = 10;
    int *ptr = &num;

    printf("num = %d\n",num);
    printf("num with ptr = %d\n",*ptr);
    printf("Address of num = %u\n",&num);
    printf("Address of num with pointer = %u\n",ptr);
   
    ptr++; // increments the pointer with 4 bytes as per scale factor
    // 
   
    printf("num = %d\n",num);
    printf("num with ptr = %d\n",*ptr);
    printf("Address of num = %u\n",&num);
    printf("Address of num with pointer = %u\n",ptr);
    
    return 0;
}