// pointer to pointer
#include<stdio.h>

int main()
{
    int num = 10; // normal variable
    int *ptr = &num; // pointer variable
    int **p_ptr = &ptr; // pointer to pointer

    printf("num = %d\n",num); // 10
    printf("num with pointer = %d\n",*ptr); // 10
    printf("num with pointer to pinter = %d\n",**p_ptr); // 10



    return 0;
}