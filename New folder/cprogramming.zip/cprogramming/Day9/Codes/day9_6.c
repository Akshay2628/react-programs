// pointer arithmetic
#include<stdio.h>
int main()
{
    int num = 10;
    int *ptr = &num;
    printf("num = %d\n",num);
    printf("num with ptr = %d\n",*ptr);
   /*
    ++*ptr;// increments the value at num
    printf("num = %d\n",num);
    printf("num with ptr = %d\n",*ptr);

    *ptr++; // increments the pointer ptr
    printf("num = %d\n",num);
    printf("num with ptr = %d\n",*ptr);
    
    (*ptr)++; // increments the value

    *++ptr; // increments pointer
    
    */
    
    return 0;
}