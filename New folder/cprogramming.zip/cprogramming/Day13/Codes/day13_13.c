
#include<stdio.h>
#include<string.h>

struct employee
{
    int emp_id;
    char name[50];
    int salary;
}e1; // variable

int main()
{
    e1.emp_id = 101;
    e1.salary = 1000;
    strcpy(e1.name,"nisha");

    printf("%d   %s  %d",e1.emp_id,e1.name,e1.salary);



    return 0;
}