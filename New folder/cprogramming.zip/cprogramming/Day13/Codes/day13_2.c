// dynamic memory allocation -> calloc
#include<stdio.h>
#include<stdlib.h>

int main()
{
    int *ptr,count = 4;

    ptr = (int *) calloc(count, sizeof(int));

    for(int i = 0;i<count;i++) // assigning values
    {
        *(ptr+i) = i+10; // 0+10 = 10
    }

    for(int i = 0;i<count;i++) // printing values
    {
        printf("%4d",ptr[i]);
    }
free(ptr);
ptr = NULL;

    return 0;
}