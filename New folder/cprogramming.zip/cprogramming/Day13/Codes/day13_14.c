// different ways of structure declarations
#include<stdio.h>

struct
{
    int emp_id;
    int salary;
} emp; // variable for anonymous structure


typedef struct employee
{
    int roll_no;
    int marks;
}emp; // another name for the structure

// employee is original name  -> variable creation -> employee e1
// emp is another/ alias name -> variable creation ->  emp e2

typedef struct
{
    int roll_no;
    int marks;
}emp;

// emp is the name of the structure -> variable creation -> emp e1;