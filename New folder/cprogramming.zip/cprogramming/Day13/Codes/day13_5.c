#include<stdio.h>
//#define SQR(x) (x) * (x)
//#define SQR(x) x * x

int main()
{
    int num = 5;
    printf("sqr = %d\n",SQR(num));
    printf("sqr = %d",SQR(num+2));
                        // num * num


    return 0;
}