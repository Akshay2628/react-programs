// structures declaration, scanning and printing 

#include<stdio.h>

struct student
{
    int roll_no;
    char name[20];
    float marks;
};

int main()
{
    struct student s1 = {1,"nisha",100}; // intialization

    printf("%d   %s   %.2f\n",s1.roll_no,s1.name,s1.marks);

    printf("Enter the Roll no :");
    scanf("%d",&s1.roll_no);

    printf("enter the name ::");
    scanf("%s",s1.name);

    printf("enter the marks ::");
    scanf("%f",&s1.marks);

    printf("%d   %s   %.2f",s1.roll_no,s1.name,s1.marks);
    return 0;
}