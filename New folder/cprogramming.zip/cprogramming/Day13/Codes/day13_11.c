#include<stdio.h>
// predefined directives
int main()
{
    printf("line no = %d\n",__LINE__);
    #line 100
    printf("line no = %d\n",__LINE__);

    printf("Date = %s\n",__DATE__);
    printf("Time = %s\n",__TIME__);
    printf("File = %s",__FILE__);
    
    return 0;

}