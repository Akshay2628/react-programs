#include<stdio.h>
#define print(a,b) printf("%d",a##b)
                    //## concat

int main()
{
    int basicsal = 5000;
    print(basic,sal);
    // printf("%d",basicsal);

    return 0;
}