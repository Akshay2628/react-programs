#include<stdio.h>
#define print_mul(a,b) printf(#a "*" #b "=%d",a*b)
                           // # converts it into string -> "a"
int main()
{
    int num1 = 10,num2 = 20;
    print_mul(num1,num2);
   // printf(#a "*" #b "=%d",a*b)
   //printf("num1" "*" "num2" "=%d",num1*num2);
  // printf("num1 * num2 = %d",num1*num2);
    return 0;
}