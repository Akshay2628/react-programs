
// array of structure
#include<stdio.h>
#define ROW 3
struct student
{
    int roll_no;
    char name[20];
    float marks;
};

int main()
{
    struct student s1[ROW]; // array of structure variable s1

    printf("enter the data ::");
    for(int i=0;i<ROW;i++)
    {
        printf("Enter the roll no for student %d::",i+1);
        scanf("%d",&s1[i].roll_no);

        printf("Enter the name for student %d ::",i+1);
        scanf("%s",s1[i].name);

        printf("Enter the marks for student %d ::",i+1);
        scanf("%f",&s1[i].marks);

    }

    printf("Student data ::\n");

    for(int i=0;i<ROW;i++)
    {
        printf("Student %d ::\n",i+1);
        printf("Roll no = %d\n",s1[i].roll_no);
        printf("Name = %s\n",s1[i].name);
        printf("MArks = %.2f\n",s1[i].marks);
        
     }
    return 0;
}