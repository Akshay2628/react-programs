// #error -> to display error
#include<stdio.h>
#define PI 3.14
int main()
{
    #ifndef PI
    #error "PI is undefined"

    #else
        printf("PI is defined");
    #endif
        
    return 0;
}