#include<stdio.h>
//conditional directives
#define PI 3.14

int main()
{
    #ifdef PI
        printf("PI is defined");
    #else
        printf("PI is not defined");
    #endif

    #undef PI // undefine PI
    return 0;
}