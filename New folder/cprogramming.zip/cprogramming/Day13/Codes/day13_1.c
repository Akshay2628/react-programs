
// dynamic memory allocation -> malloc()
#include<stdio.h>
#include<stdlib.h>

int main()
{
    int *ptr;
    // malloc syntax -> (void *) malloc(size_t size)

   // ptr = (int *) malloc(sizeof(int)); // allocating memory for 1 int variable
    //*ptr = 10; // assigning value to that location

    ptr = (int *) malloc(sizeof(int)*3); // allocating memory for 3 int variables
    printf("Enter 3 values ::"); 
    for(int i =0;i<3;i++) // scanning values 
    {
        scanf("%d",&ptr[i]);
    }

printf("Values are :"); // printing values
    for(int i =0;i<3;i++)
    {
        printf("%4d",ptr[i]);
    }

    free(ptr); // free the memory
    ptr = NULL; // avoid dangling pointer

    return 0;
}