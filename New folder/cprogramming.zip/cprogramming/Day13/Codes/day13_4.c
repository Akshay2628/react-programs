// macros
#include<stdio.h>
#define PI 3.14

#define row 3 // for 2-D array
#define col 4 // for 2-D array

int main()
{
    printf("PI = %.2f",PI);
    return 0;
}
