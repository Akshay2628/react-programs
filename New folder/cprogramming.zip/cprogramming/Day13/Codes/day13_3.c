// dynamic memory allocation -> realloc
#include<stdio.h>
#include<stdlib.h>

int main()
{
    int *ptr,count = 4;

    ptr = (int *) calloc(count, sizeof(int));

    if(ptr == NULL)
        printf("Memory not allocated !");

    for(int i = 0;i<count;i++)
    {
        *(ptr+i) = i+10; // 0+10 = 10
    }

    for(int i = 0;i<count;i++)
    {
        printf("%4d\n",ptr[i]);
    }
printf("After reallocation !\n");

    ptr = (int *) realloc (ptr,6 * sizeof(int));

    ptr[4] = 14;
    ptr[5] = 15;

      for(int i = 0;i<6;i++)
    {
        printf("%4d\n",ptr[i]);
    }


free(ptr); 
ptr = NULL;

    return 0;
}