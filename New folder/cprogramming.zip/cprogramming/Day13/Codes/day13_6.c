#include<stdio.h>
#define swap(a,b,type) {type temp; temp = a; a= b; b = temp;}


int main()
{
    int num1 = 10,num2 = 20;
    printf("Values before swap\n num1 = %d  num2 = %d\n",num1,num2);
    swap(num1,num2,int);
     printf("Values after swap\n num1 = %d  num2 = %d",num1,num2);
    return 0;
}