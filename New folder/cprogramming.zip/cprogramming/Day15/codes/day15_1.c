// self referential structures
#include<stdio.h>

struct test
{
    int num1;
    int num2;
    struct  test *ptr;
};

int main()
{
    struct test t1;
    t1.num1 = 10;
    t1.num2 = 20;
    t1.ptr = NULL;

    struct test t2;
    t2.num1 = 30;
    t2.num2 = 40;
    t2.ptr = NULL;

    t1.ptr = &t2;
    
    printf("t1 : num1 = %d  num2 = %d\n",t1.num1,t1.num2);

    printf("t2 : num1 = %d  num = %d\n",t2.num1,t2.num2);

    printf("t2 using ptr of t1 : num1 = %d num2 = %d",t1.ptr->num1,t1.ptr->num2);
    return 0;
}
