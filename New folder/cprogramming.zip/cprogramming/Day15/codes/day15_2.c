// file handling

#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int main()
{
    FILE *fptr; // typedef name of a predefined structure
    char ch;

    fptr = fopen("sunbeam.txt","w"); // file opned in write mode

    if(fptr == NULL)
        printf("File not created !!");

    printf("Please enter the data !");

     while((ch=getchar()) != EOF) // End Of File
    {
       fputc(ch,fptr); // predefined function to put the char into file
    }
/*
    if(fptr != NULL)
      fprintf(fptr,"Nisha Dingare!"); // print the data in the file*/

     // printf("Data entered !");
    fclose(fptr);

    return 0;
}