#include<stdio.h>

int main()
{
    FILE *fptr;
    char ch;
    fptr = fopen("sunbeam.txt", "a"); // file opened for appendning the data

    if(fptr == NULL)
    {
        printf("File not opened !!");
    }

   /* while ((ch = getchar()) != EOF)
    {
        fputc(ch,fptr);
    }*/

    if(fptr != NULL)
        fprintf(fptr, " trainer in sunbeam !");
    printf("Data entered !!");
    fclose(fptr);
    return 0;
}