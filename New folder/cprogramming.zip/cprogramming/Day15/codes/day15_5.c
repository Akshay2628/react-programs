#include<stdio.h>

int main()
{
    FILE *fptr;
    char ch;
    fptr = fopen("sunbeam.txt","r");

    printf("File position = %ld\n",ftell(fptr));

    fseek(fptr,7,SEEK_SET); // seek_set -> beggining of the line
    ch = fgetc(fptr);
    printf("File position = %ld  char = %c\n",ftell(fptr),ch);

    fseek(fptr,5,SEEK_CUR); // goes ahead from current position
    ch = fgetc(fptr);
    printf("File position = %ld  char = %c\n",ftell(fptr),ch);

    fseek(fptr,-3,SEEK_CUR); // goes backwards from current position
    ch = fgetc(fptr);
    printf("File position = %ld  char = %c\n",ftell(fptr),ch);

    fseek(fptr,-5,SEEK_END); // goees backwards from the end
    ch = fgetc(fptr);
    printf("File position = %ld  char = %c\n",ftell(fptr),ch);

    return 0;
}