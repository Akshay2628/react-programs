#include<stdio.h>

int main()
{

    FILE *fptr;
    char ch;

    fptr = fopen ("day15_1.c","r"); // file opened for reading the data

    if(fptr == NULL)
        printf("file not opened !!");


    while ((ch=fgetc(fptr)) != EOF)
    {
       // printf("%c",ch);   
       fputc(ch,stdout);
    }
    fclose(fptr);

    return 0;
}