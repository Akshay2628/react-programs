#include<stdio.h> // standard input output header file

int main() 
// main() -> entry point function -> user defined function
// int -> return type
{
    printf("Hello PH14.. Welcome to sunbeam !!\n");
    // predefined function
    return 0; // exit status -> success
}

/*
    multi line
    comments
*/