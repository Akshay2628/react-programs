// assignment op, comma op
#include<stdio.h>
int main()
{
    int num1 = 10; // = assignment op
   // int num2 = 1,2,3; // not allowed with initialization
   int num3;
   num3 = 1,2,3; // comma operator -> allowed after declaration
   printf("num3 = %d\n",num3); // leftmost value assigned for num3 -> 1
   int num4 = (1,2,3); // rightmost value assigned
   printf("num4 = %d",num4); // 3
    return 0;
}