// unary ops : ++ --
/* post increment op assignes the value first, then increments 
pre increment op increments the value first then assigns
*/
#include<stdio.h>
int main()
{
    int num1 = 10,num2 = 20;
    int res = num1++; // post increment op
    printf("num1 = %d  res = %d\n",num1,res);
    res = ++num1; // pre - increment op -> num1 = 11 + 1
    printf("num1 = %d  res = %d\n",num1,res);

    int res1 = num2--; // post decrement op
    printf("num2 = %d  res1 = %d\n",num2,res1);
    res1 = --num2; // pre decrement
    printf("num2 = %d  res = %d\n",num2,res1);


    return 0;
}
