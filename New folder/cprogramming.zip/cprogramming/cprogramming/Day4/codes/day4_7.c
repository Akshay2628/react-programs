// unary ops ++ -- with , and ()

#include<stdio.h>

int main()
{
    int num1 = 10,num2 = 20;
    int res ;
    res = ++num1,num1++,++num1; // left most value is assigned
    int res1;
    res1 = (num2++,++num2,num2++); // rightmost value is assigned

    printf("num1 = %d  res = %d\n",num1,res);
    printf("num2 = %d  res1 = %d",num2,res1);
    return 0;
}