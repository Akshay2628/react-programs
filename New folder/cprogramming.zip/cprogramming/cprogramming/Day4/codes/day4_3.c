// short hand ops
#include<stdio.h>
int main()
{
    int num1 = 10,num2 = 20;

    num1 += num2;
    // num1 = num1 + num2;

    printf("num1 = %d  num2 = %d\n",num1,num2);
   
    num1 -= num2;
   // num1 = num1 - num; // short hand op performing substraction
  
  printf("num = %d  num2 = %d\n",num1,num2);

// num1 =- num2; // assignment op assigning negative value

  num1 *= num2;
  printf("num1 = %d  num2 = %d",num1,num2);
    return 0;
}