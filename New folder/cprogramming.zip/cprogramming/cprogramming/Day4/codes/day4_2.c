// division and mod op
#include<stdio.h>
int main()
{
    int num1 = 10,num2 = 5;

    int ans = num1 / num2; // division -> quotient
    printf("division = %d\n",ans);
    ans = num1 % num2; // mod -> remainder
    printf("Mod = %d",ans);
    return 0;
}