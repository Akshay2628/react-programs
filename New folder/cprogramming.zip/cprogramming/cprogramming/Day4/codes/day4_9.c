// if  - conditional statements - control statements

#include<stdio.h>
int main()
{
    int num1 ,num2;
    printf("Enter value for num1 ::");
    scanf("%d",&num1);

    printf("enter value for num2 ::");
    scanf("%d",&num2);

    if(num1 > num2)
    
        printf("Num1 is greater !!");
    
    else
    {
        printf("Num2 is greater !!");
    }
    
    return 0;
}