// logical ops : &&  ||  !
/* && returns true if both conditions are true
if 1st condition of && is false, it does not check 2nd condition.

|| returns true is either of one conditions is true
if 1st condition is true it does not check 2nd condition
*/
#include<stdio.h>
int main()
{
    int num1,num2;

    printf("Enter value for num1 ::");
    scanf("%d",&num1);
    printf("Enter value for num2 ::");
    scanf("%d",&num2);

  //  printf("num1 && num2 ? = %d\n", num1 && num2); // logical &&
  //  printf("num1 || num2 ? = %d", num1 || num2 ); // logical ||
  //  printf("num1 = %d\n",num1);
   // printf("!num1 = %d\n",!num1);
    printf("num1 && num2 ? = %d\n",num1 && num2);
    printf("num1 && num2 ? = %d",!(num1 && num2));
    return 0;
}