// unary ops with logical ops
#include<stdio.h>

int main()
{
    int num1 = 0,num2 = 0;
  // int res = num1++ || ++num2;

   // printf("num1 = %d  num2 = %d  res = %d\n",num1,num2,res);
    printf("ans = %d ",!(num1++ || ++num2));
    printf("num1 = %d  num2 = %d",num1,num2);
    return 0;
}