// relational ops ::
// < <= > >= != ==
// output = 1 (true) 0(false)

#include<stdio.h>
int main()
{
    int num1,num2 ;
    printf("Enter value for num1 ::");
    scanf("%d",&num1);
    printf("Enter value for num2 ::");
    scanf("%d",&num2);


    printf("num1 > num2 ? = %d\n",num1 > num2);
    printf("num1 != num2 ? = %d\n", num1 != num2);
    printf("num1 == num2? = %d\n", num1 == num2);
    printf("num1 < num2 ? = %d\n",num1 < num2 );
    printf("num1 >=num2 ? = %d\n",num1 >= num2);
    printf("num1 <= num2 ? = %d\n",num1 <= num2);
    return 0;
}