#include<stdio.h>
#include<limits.h>

int main()
{
    printf("%d\n",INT_MIN);
    printf("%d\n",INT_MAX);
    return 0;
}

/*
int = 4 bytes
1 byte = 8 bits
4 * 8 = 32 bits

(2^32 - 1) -1
2^31 -1
positive numbers start from 0 to ----- max range
*/