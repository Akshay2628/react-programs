// runtime error
#include<stdio.h>
int main()
{
    int num = 5;
    printf("printf 1 ::");
    int result = num / 0; // runtime error
    printf("printf 2 ::");
    return 0;
}