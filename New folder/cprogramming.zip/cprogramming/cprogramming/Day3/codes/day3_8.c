// octal hexa decimal formats
#include<stdio.h>

int main()
{
    int num1 = 10; // decimal 
    int num2 = 0100; // octal 
    int num3 = 0X100; // hexadecimal 

    printf("%d  %o  %x",num2,num2,num2);
    return 0;
}