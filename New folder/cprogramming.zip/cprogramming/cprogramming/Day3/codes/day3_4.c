// arithmetic op with sizeof
#include<stdio.h>

int main()
{
    int num = 10;
    char ch = 'Z';
    float fvar = 12.33;
    double dvar = 15.44;

    printf ("size of int = %d\n",sizeof(int)); // 4 bytes
    printf(" %d",sizeof(num+dvar)); // 8 bytes
    printf("\n%d",sizeof(num + ch)); // 4 bytes
    return 0;
}