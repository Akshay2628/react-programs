// char range
#include<stdio.h>
#include<limits.h> // ranges of int and char
#include<float.h> // ranges of float and double

int main()
{
    unsigned char ch;
    printf("Min = %d",CHAR_MIN);
    printf("\n Max = %d",CHAR_MAX);
    printf("\nunsigned max = %d",UCHAR_MAX);
}
/*
char = 1 byte
1 byte = 8 bits
1 * 8 = 8
(2^8 -1) - 1
2^7 -1
128 -1
127
*/
/*
unsigned char = 1 byte
1 byte = 8 bits
(2^8) -1
256 -1
255
*/