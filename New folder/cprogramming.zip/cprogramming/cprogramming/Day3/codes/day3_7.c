#include<stdio.h>

int main()
{
    char ch1 = 'A';
    char ch2 = 'B';
    char sum;
    int add;
    unsigned char addition ;
    sum = ch1 + ch2; // A + B -> 65 + 66 = 131-> out of range -> -125
    printf("sum of ch1 and ch2 = %d\n",sum);
    add = ch1 + ch2; // int type -> 131 -> in range of int
    printf("sum of ch1 and ch2 = %d\n",add);
    addition = ch1 + ch2; // in range of unsigned char
    printf("Addition of ch1 and ch2 = %d",addition);
    return 0;
}

/*
signed char range = -128 to 127
131 -> out of range 

-128  -127  -126  -125  -124 ...... -1 0 1 2 3 4 ...... 127
128    129   130   131
corresponding value of 131 is -125

*/