#include<stdio.h>
int main()
{
    int num = 12.34; // downcasting

    printf("%d",num);
    float fvar = (float) 5/3; // explicit typecasting -> upcasting
    printf("\n%.2f",fvar);
    return 0;
}