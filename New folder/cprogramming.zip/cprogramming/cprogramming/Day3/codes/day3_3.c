// scanf with num and char
#include<stdio.h>

int main()
{
    int num1;
    char ch;
    printf("Enter value for num1 ::");
    scanf("%d",&num1);
    printf("Enter value for ch ::");
    scanf("%*c%c",&ch); // used to suppress the enter or space keys
    printf("Value for num1 = %d\n value for ch = %c",num1,ch);
    return 0;
}