// width specifier
#include<stdio.h>

int main()
{
    int num1 = 10;
    int num2 = 20;
    float fvar = 12.34;
    printf("%d,%4d\n",num1,num2); // right justified -> spaces to the left
    printf("%-6d,%d\n",num1,num2); // left justified -> spaces to the right
    printf("%6.3f\n",fvar);
    printf("%7.3f",fvar);

    return 0;
}