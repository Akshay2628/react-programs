// return of scanf
#include<stdio.h>
int main()
{
    int num1,num2,count;
    printf("Enter the value for num1 and num2 ::");
    count = scanf("%d%d",&num1,&num2);
    printf("count = %d",count);
    return 0;
}