// count of printf 
#include<stdio.h>

int main()
{
    int count;
    int num = 5000;
    /*count = printf("Good Morning everyone !!");
    printf("\ncount = %d",count);*/
    count = printf("%d",num); // 5000 -> 4 count
    printf("\n count = %d",count);

    return 0;
}