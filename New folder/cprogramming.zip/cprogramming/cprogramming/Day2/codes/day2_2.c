// 1 byte = 8 bits
// int gets 4 bytes
// char gets 1 byte
// float gets 4 bytes
// double gets 8 bytes
// sizeof() is an operator which returns the size of bytes allocated to a variable.

#include<stdio.h>
int main() // function
{
    int num1 = 10; // variable
    char ch = 'a';
    float fvar = 12.33;
    printf("size of int = %d\n",sizeof(num1)); // 4
    printf("size of char ch = %d\n",sizeof(ch)); // 1
    printf("size of A = %d\n",sizeof('A')); // 4
    printf(" size of float = %d\n",sizeof(fvar)); // 4
    printf("size of 12.33 = %d\n",sizeof(12.33)); // 8
    // by default number with decimal point are considered as double
    printf("size of 12.33 = %d\n",sizeof(12.33f)); // 4 - size of float
                                        // f denotes float
    return 0;
}