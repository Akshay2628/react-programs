// types of main
#include<stdio.h>

int main()
{
    return 0; // success
}

void main() // void = nothing
{
   //------
   //---- 
} 

void       main(void)
//output      // input
{

}

