/* datatypes 
    int
    float
    char
    double
*/
//variable declaration and printing
#include<stdio.h> // standard input output header file

int main()
{
    int num; // declaration
    num = 10; // assigning value
    float fvar = 12.33; // initialization = declaration + assignment
    char ch = 'A'; // initialization
    double dvar = 12.45;

    printf("num = %d\n", num); // %d is format specifier for integer
    printf("fvar = %.2f\n",fvar); // %f is format specifier for float
    printf("ch = %c\n",ch); // %c is format specifier for char
    printf("dvar = %.3lf",dvar); // %lf is format specifier for double
    return 0;
}