// scanf - predefined library function
#include<stdio.h>
int main()
{
    int num = 10;
    printf("enter value for num ::");
    scanf("%d",&num); // & - addressof op
    printf("Value for num = %d",num); 
   
    return 0;
}