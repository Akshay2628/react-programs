// Escape Sequences
#include<stdio.h>

int main()
{
    printf("Hello Ph14\n"); // \n - new line
    printf("\tHello PH14\n"); // \t - horizontal tab -  8 spaces ahead
    printf("123456789\n");
    printf("hello PH14\rH"); 
    // \r - carriage return - takes cursor to starting char of current line
    printf("Good Morning\rGreat\n");
    printf("Hello PH13\b4\n");
    // \b - backspace - goes 1 position back from current position
    printf("\"Hello Please come back soon after break \"\n");
    // prints " " in output

    printf("\'Good  morning \'\n");
    // prints ' ' in output
    printf("Scored 70%%\n");
    // prints % in output
    printf("\\n = new line");
    // prints \ in output 
    return 0;
}