#include<stdio.h>

int main()
{
    char ch = 'A';
    printf("char ch = %c\n",ch);// prints character
    printf("char ch with ascii value = %d",ch); // prints ascii value of A
    return 0;
}