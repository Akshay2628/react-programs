// switch case -> calculator

#include<stdio.h>

int main()
{
    int num1,num2,choice;

    printf ("Enter values for num1 and num2 ::");
    scanf("%d%d",&num1,&num2);
    printf("Enter 1. Add \n 2.Subtract \n 3.Multiply \n 4. Divide :");
    scanf("%d",&choice);

    switch (choice)
    {
         case 2+1:
            printf("Multiplication = %d",num1 * num2);
            break;
        case 1 :
            printf("Addition = %d\n",num1+num2);
            break;
        case 2:
            printf("Subtraction = %d",num1 - num2);
            break;
       
        case 4:
            printf("Division = %d",num1 / num2);
            break;
        default :
            printf("enter valid choice !");
            break;
    }

    return 0;
}