// valid syntax :
#include<stdio.h>
int main()
{
    // for(initializatio;condition;modification)

    int i =1;
    for(;i<=10;i++)
    {

    }
    for(;i<=10;)
    {
        i++;
    }
    
    for(;;)
    {
        
    }
    for(i=1;i<10;i++);
    {
        printf("%d",i);
    }
    printf("%d",i);
    return 0;
}