// exit control loop - Do - while
// condition is checked at the exit. loop entered atleast once
#include<stdio.h>

int main()
{
    int num = 3;

    do
    {
        printf("num = %d",num);
        num++;
       
    } while (num >=5);
    
    return 0;
}