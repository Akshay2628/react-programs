//entry controlled loops -> while loop
#include<stdio.h>

int main()
{
    int num,i = 1; //i -> control variable initialization
    printf("enter the number to print the table ::");
    scanf("%d",&num);

    while (i<=10) // condition checking
    {
        printf("%d * %d = %d\n",num,i,num*i);
        i++;    //control variable modification
    }
    


    return 0;
}
