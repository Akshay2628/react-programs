// switch case with char
#include<stdio.h>

int main()
{
    int num1,num2;
    char choice;

    printf ("Enter values for num1 and num2 ::");
    scanf("%d%d",&num1,&num2);
    printf("Enter 1. Add \n 2.Subtract \n 3.Multiply \n 4. Divide :");
    scanf("%*c%c",&choice);

    switch (choice)
    {
         
        case '+' :
            printf("Addition = %d\n",num1+num2);
            break;
        case '-':
            printf("Subtraction = %d",num1 - num2);
            break;
       case '*':
            printf("Multiplication = %d",num1 * num2);
            break;

        case '/':
            printf("Division = %d",num1 / num2);
            break;

        default :
            printf("enter valid choice !");
            break;
    }

    return 0;
}