// typedef - giving another name to the exisiting datatypes or enums

#include<stdio.h>

int main()
{
    typedef unsigned int un_int;
    un_int num1;
    un_int num2;
    typedef int number;
    number num3;
  //   enum {management,HR,Sales,Training} depts;  //anonymous enum -> depts is variable
    typedef enum department {Sales,HR,Managing,Training} Dept; // Dept is another name
    Dept d1; // d1 is a variable
    return 0;
}