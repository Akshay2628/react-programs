// do - while with menu driven program
#include<stdio.h>

int main()
{
    int num1,num2,choice;

    printf ("Enter values for num1 and num2 ::");
    scanf("%d%d",&num1,&num2);
do
{
    printf("Enter 1. Add \n 2.Subtract \n 3.Multiply \n 4. Divide :");
    scanf("%d",&choice);

    switch (choice)
    {
         
        case 1 :
            printf("Addition = %d\n",num1+num2);
            break;
        case 2:
            printf("Subtraction = %d",num1 - num2);
            break;
        case 3:
            printf("Multiplication = %d",num1 * num2);
            break;
        case 4:
            printf("Division = %d",num1 / num2);
            break;
        default :
            printf("enter valid choice !");
            break;
    }
}while (choice != 0);

    return 0;
}