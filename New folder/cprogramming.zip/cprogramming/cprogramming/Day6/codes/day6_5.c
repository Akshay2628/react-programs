// anonymous enum
#include<stdio.h>

int main()
{
    enum {management,HR,Sales,Training} depts; // anonymous enum
                                        // dept is variable

    return 0;
}