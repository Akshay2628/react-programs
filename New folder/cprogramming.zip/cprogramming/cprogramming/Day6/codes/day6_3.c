#include<stdio.h>

int main()
{
    int months;
    printf("Enter the month to check the no of days :");
    scanf("%d",&months);

    switch (months)
    {
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
            printf("this month has 31 days !!");
            break;
        case 2:
            printf("This month has 28/29 days !!");
            break;
        case 4:
        case 6:
        case 9:
        case 11:
            printf("This month has 30 days !!");
            break;
        default:
            printf("enter valid month !!");
            break;
    }
    return 0;
}