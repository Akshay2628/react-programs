// shift ops -> bitwise
#include<stdio.h>

int main()
{
    int num1 = 15,num2;
    printf("left shitf = %d\n",15<< 2); // left shift operator
    printf("%d",num1 >> 3); // right shift op
    return 0;
}

