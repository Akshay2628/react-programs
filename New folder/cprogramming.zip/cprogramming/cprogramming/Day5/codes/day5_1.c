// logical && ||
#include<stdio.h>
int main()
{
    int num1=0,num2=7,num3 = 9;

    int ans = num1++ || ++num2 && num3++;
    printf("num1 = %d  num2 = %d  num3 = %d  ans = %d",num1,num2,num3,ans);
    return 0;
}