// bitwise op : & | ^ ~

#include<stdio.h>
int main()
{
    int num1 = 15, num2 = 17;

  //  printf("num1 & num2 = %d\n", num1 & num2); // bitwise & -> AND
   printf("num1 | num2 = %d\n",num1 |num2); // bitwise | -> OR
   printf("num1 ^ num2 = %d\n",num1 ^ num2); // bitwise ^ -> XOR
   printf("~ num1 = %d\n",~num1); // bitwise compliment 
   printf("~num2 = %d",~num2); // formula -> -(n + 1) = -(17 + 1) = -18
    return 0;
}