// nested if - else
#include<stdio.h>
int main()
{
    int num1, num2,num3;
    printf("enter value for num1,num2,num3 ::");
    scanf("%d%d%d",&num1,&num2,&num3);

    if (num1 > num2)
    {
        if(num1 > num3) // nested if
        {
            printf("Num1 is greater !!");
        }
        else // else for nested if
        {
            printf("Num3 is greater !!");
        }
        
    }
    else if(num2 > num3)
    {
        printf("Num2 is greater !!");
    }
    else
    {
        printf("Num3 is greater !!");
    }
    
   
    
    return 0;
}