// conditional operator -> ternary op
//syntax : condition ? expression1 : expression2

#include<stdio.h>

int main()
{
    int age;
    printf("enter your age ::");
    scanf("%d",&age);

    age >= 18 ? printf("Eligible for voting !") : printf("Not eligible for voting !");
    return 0;
}