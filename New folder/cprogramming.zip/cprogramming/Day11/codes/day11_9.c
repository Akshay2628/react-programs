#include<stdio.h>
#include<string.h>

int main()
{
    char str1[] = "sunbeam";
    char str2[50] ,*ptr;
    char ch = 'b';
   // str2 = str1; // not allowed

   strcpy(str2,str1); // pre defined function to copy 1 string to another

   printf("str2 = %s\n",str2);
/*
 ptr = strchr(str1,ch); // predefined function to find char from string
 if (ptr == NULL)
    printf("char not found\n");
else 
    printf("char found at index location = %d\n",ptr-str1);*/

    printf("%s",strrev(str1)); // predefined function to reverse the string

    return 0;
}