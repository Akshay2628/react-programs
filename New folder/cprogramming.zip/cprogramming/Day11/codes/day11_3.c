//scan sets
#include<stdio.h>

int main()
{
    char name[50];

    printf("Enter your name ::");
  //  scanf("%[^\n]s",name); // scans till new line
  //scanf("%[^A-Z]s",name); // scans till any capital letter is encountered
  //scanf("%[^0-9]s",name); // scans till any number is encountered
  //scanf("%[A-Z]s",name); // scans all capital letters
  scanf("%[^.]s",name); // scans till . is encountered -> multiline scaning

    printf("%s",name);
    return 0;
}