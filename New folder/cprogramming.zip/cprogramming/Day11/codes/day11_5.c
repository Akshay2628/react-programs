// char pointer
//char pointer is defined in RO data section
#include<stdio.h>

int main()
{
    char str1[] = "sunbeam"; // string
    char *str2 = "sunbeam"; // char pointer

    printf("size of str1 = %d\n",sizeof(str1)); // 8
    printf("size of str2 = %d\n",sizeof(str2)); // 4 -> size of pointer in 32 bit

    str1[2] = 'N'; // possible
    printf("%s\n",str1);
    str2[2] = 'N'; // not possible in case of char pointer : gives runtime error
    printf("%s\n",str2);
    printf("end of block");

    return 0;
}