// 2-d arrays declarations
#include<stdio.h>

int main()
{
    int arr[3][3] = {1,2,3,4,5,6,7,8,9};
    int arr1[3][3] = {{1,2,3},{4,5,6},{7,8,9}};
    int arr2[][3] = {1,2,3,4,5,6,7,8,9};
    int arr3[][3] = {1,2,3,4,5,6,7};

}