// char pointer comparison
#include<stdio.h>

int main()
{
    char *ptr = "sunbeam"; // created on RO data section
    char *ptr1 = "sunbeam";

    if(ptr == ptr1)
    {
        printf("Equal");
    }
    else
    {
        printf("not equal");
    }
    
    return 0;
}