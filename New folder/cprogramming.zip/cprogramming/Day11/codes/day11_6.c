// print a particular char
// print string after char
// arithmetic ops with char
#include<stdio.h>

int main()
{
    char str1[] = "sunbeam";

   printf("%c\n",str1[3]); // prints char at index 3 -> char notation
   printf("%c\n",*(str1+2)); // prints char at index 2 -> pointer notation

   printf("%s\n",str1+3); // prints string from index 3 till \0
    printf("%c\n",*str1+3); // value at str1 + 3 is added
   printf("%c",*(str1+2)+5); // value at index 2 + 5 is added



    return 0;
}