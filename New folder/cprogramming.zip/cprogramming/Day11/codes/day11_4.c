#include<stdio.h>
#include<string.h>

int main()
{
    char str1[] = "sunbeam Info";
    char str2[] = "sunbeam\0Info";
    printf("size of str1 = %d\n",sizeof(str1)); // 12 + 1 (internal \0) = 13
    printf("size of str2 = %d\n",sizeof(str2)); // 13

    printf("length of str1 = %d\n",strlen(str1)); // 12
    // strlen is predefined function from string.h it returns num of characters till \0
    printf("length of str2 = %d\n",strlen(str2)); // 7
    // excludes \0
    return 0;
}
/*



typedef of unsigned long long is size_t

strlen -> return type is size_t
*/