#include<stdio.h>
// char and string declarations
int main()
{
    char str1[5] = {'A','B','C','D','E'}; // char array
    // initialization list should be explicitly ended with \0 to make it string
    char str2[5] = {'a','b','c','d','\0'}; // string
    char str3[5] = {'X','Y','Z'}; // remaining elements intialized to 0-> string
   
    char str4[5] = "tech"; // string-> internally \0 is initialized
   
   
    char str5[] = {'s','u','n','b','e','a','m'}; //char array

    char str6[] =  "nisha"; // string
    
    
    char str7[4] = "pune"; // char array
    
    char str8[] = "sunbeam Info"; // string
    return 0;
}