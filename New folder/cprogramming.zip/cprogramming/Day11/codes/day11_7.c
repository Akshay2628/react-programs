// string comparisons
#include<stdio.h>
#include<string.h>
int main()
{
    char str1 [] = "sunbeam";
    char str2 [] = "Sunbeam";

    /*if(str1 == str2)
    {
        printf("same");
    }
    else
    {
        printf("Not same ");
    }*/
    int result = strcmp(str1,str2);
    printf("Result = %d\n",result);
    if(result == 0)
        printf("strings are equal !!");
    else if (result > 0)
        printf("string 1 is bigger");
        else
        {
            printf("string 2 is bigger");
        }
        // stricmp -> ignore the cases
        
    return 0;
}