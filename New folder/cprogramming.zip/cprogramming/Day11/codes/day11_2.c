#include<stdio.h>

int main()
{
    char name[20];

    printf("enter your name ::");
   // scanf("%s",name); // scans only till white spaces
   gets(name); // function to get the string from the user (but not used as it has disadvantages)
   // scans till newline
    printf("name = %s",name);

    return 0;
}