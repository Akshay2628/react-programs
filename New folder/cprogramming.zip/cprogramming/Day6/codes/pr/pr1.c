// enum with year
#include<stdio.h>

int main()
{
    enum year{jan,feb,mar,apr,may=50,jun,jul,aug,sept,oct,nov,dec};
    enum year month; // enum year is a datatype , month is a variable

    printf("Enter value for month :");
    scanf("%d",&month);
    

    switch (month) 
    {
        case jan :
        case mar :
        case may :
        case jul :
        case aug :
        case oct :
        case dec :
            printf("31 days !");
            break;
        case feb :
            printf("28 / 29 days !");
            break;
        case apr :
        case jun :
        case sept :
        case nov :
            printf("30 days !!");
            break;
        default :
            printf("Enter valid case !");
            break;
    }
    printf("size of enum = %d\n",sizeof(enum year));
    printf("size of enum = %d",sizeof(month));

    return 0;
}